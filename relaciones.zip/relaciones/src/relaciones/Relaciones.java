 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package relaciones;

/**
 *
 * @author UCF20402
 */
public class Relaciones {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Smartphone s1 = new Smartphone("Samsung Galaxy S24");
        s1.mostrar(); // Debe decir que no tiene chips aún

        System.out.println("\n=== 2. Agregando 3 Chips (más de 2) ===");
        Chip chip1 = new Chip("Movistar", 999111222);
        s1.mostrar();
        s1.agregarChip(chip1);
        s1.mostrar();
        Chip chip2 = new Chip("Claro", 888777666);
        s1.mostrar();
        s1.agregarChip(chip2);
        s1.mostrar();
        Chip chip3 = new Chip("Entel", 777666555);
        s1.agregarChip(chip3);
        s1.mostrar();


       

        

        
    }
    
}
