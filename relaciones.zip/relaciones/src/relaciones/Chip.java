/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package relaciones;

/**
 *
 * @author UCF20402
 */
public class Chip {
    
    private String  empresa;
    private int numero;

    public String getEmpresa() {
        return empresa;
    }

    public void setEmpresa(String empresa) {
        this.empresa = empresa;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }
    
     public Chip(String empresa, int numero) {
        this.empresa = empresa;
        this.numero = numero;
    }
    public void mostrar(){
        System.out.println("Empresa: "+this.empresa + 
                "numero: "+this.numero);
    }
        
   
    
    
}
