/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package relaciones;
import java.util.ArrayList;

/**
 *
 * @author UCF20402
 */
public class Smartphone {
    private String modelo;
    private int nro_chips;
    
    // Inicializamos la lista aquí para evitar NullPointerException
    private ArrayList<Chip> chips = new ArrayList<>();//atributo relacion porq ue es una agregacion
    

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getNroChips() {
        return nro_chips;
    }

    public void setNroChips(int nro_chips) {
        this.nro_chips = nro_chips;
    }

    public ArrayList<Chip> getChips() {
        return chips;
    }

    // CONSTRUCTOR: Solo recibe el modelo (texto)
    public Smartphone(String modelo) {
        this.modelo = modelo;
        this.nro_chips = 0; 
    }

    public void mostrar() {
        System.out.println("Modelo: " + this.modelo + " | cantidad de chips: " + this.nro_chips);
        
        if (this.nro_chips > 0) {
            System.out.println("y sus chips son: ");
            for (int i = 0; i < this.chips.size(); i++) {
                System.out.print("   Chip " + (i + 1) + ": ");
                chips.get(i).mostrar();
            }
        } else {
            System.out.println("No se ha agregado aún ningún chip");
        }
    }

    // MÉTODO agregarChip CON LA CONDICIÓN < 2 (como lo pediste)
    public void agregarChip(Chip nuevoChip) {
        if (this.nro_chips < 2) {
            this.chips.add(nuevoChip);
            this.nro_chips = this.nro_chips + 1;
            System.out.println("Chip de " + nuevoChip.getEmpresa() + " agregado al " + modelo + ".");
        } else {
            System.out.println("Error: ya agregó 2 chips, ya no puede agregar más.");
        }
    }
}  

   

